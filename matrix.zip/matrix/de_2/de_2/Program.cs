﻿using System;

namespace de_2
{
    class Program
    {
        public static void Main(string[] args)
        {
            int[] array = new int[0];
            int n = 0;
            bool isRun = true;

            while (isRun)
            {
                Console.Write("\n___________________________________________START___________________________________________\n\n");
                Console.Write("Nhap vao gia tri so n (0,10):");
                string temp = Console.ReadLine();
                n = Convert.ToInt32(temp);

                if (n > 0)
                {
                    Console.WriteLine("\n==> Khoi tao mang so nguyen");
                    array = InitArray(n);

                    Console.WriteLine("------------------------------- KET QUA MANG SO NGUYEN -------------------------------");
                    PrintArray(array, n);
                    Console.WriteLine("--------------------------------------------------------------------------------------\n");

                    Console.WriteLine("------------------------------- QUA TRINH SAP XEP -------------------------------");
                    insertionSort(array, n);
                    Console.WriteLine("\n---------------------------------------------------------------------------------\n");

                }
                else
                {
                    Console.WriteLine(" --------------------------------------------------");
                    Console.WriteLine("  ==> Loi! Nhap vao so nguyen duong ");
                    Console.WriteLine(" --------------------------------------------------");
                }

                Console.Write("\n____________________________________________END____________________________________________\n\n");
            }
        }

        static int[] InitArray(int n)
        {
            Random random = new Random();
            if (n > 0 && n < 10)
            {
                int[] array = new int[n];
                for (int i = 0; i < n; i++)
                {
                    array[i] = random.Next(1, 100);
                }
                Console.WriteLine();
                return array;
            }
            return null;
        }
        static void PrintArray(int[] array, int n)
        {
            Random random = new Random();
            if (n > 0 && n < 10)
            {
                for (int i = 0; i < n; i++)
                {
                    Console.Write("\t {0} ", array[i]);
                }
                Console.WriteLine();
            }
        }
        static void insertionSort(int[] arr, int n)
        {
            int i, key, j;
            Console.Write("\n\t 1.");
            PrintArray(arr, n);
            for (i = 1; i < n; i++)
            {
                key = arr[i];
                j = i - 1;

                /* Di chuyển các phần tử có giá trị lớn hơn giá trị 
                key về sau một vị trí so với vị trí ban đầu
                của nó */
                while (j >= 0 && arr[j] > key)
                {
                    arr[j + 1] = arr[j];
                    j = j - 1;
                }
                arr[j + 1] = key;
                Console.Write("\n\t {0}.", i+1);
                PrintArray(arr, n);
            }

            Console.Write("\n\t==> Ket qua sap xep: ");
            PrintArray(arr, n);
        }
    }
}
