﻿using System;

namespace de_1
{
    class Program
    {
        public static void Main(string[] args)
        {
            int[,] array = new int[0, 0];
            int n = 0;
            bool isRun = true;

            while (isRun)
            {
                Console.Write("\n___________________________________________START___________________________________________\n\n");
                Console.Write("Nhap vao gia tri so n (0,10):");
                string temp = Console.ReadLine();
                n = Convert.ToInt32(temp);

                if (n > 0 && n < 10)
                {
                    Console.WriteLine("\n==> Khoi tao ma tran cap : {0}\n", n);
                    array = InitArray(n);

                    Console.WriteLine("------------------------------- KET QUA MA TRAN -------------------------------");
                    PrintArray(array, n);
                    Console.WriteLine("-------------------------------------------------------------------------------\n");

                    Console.WriteLine("-------------------------- CAC BO GIA TRI GIONG NHAU --------------------------");
                    GetSameValue(array, n);
                    Console.WriteLine("-------------------------------------------------------------------------------\n");
                }
                else
                {
                    Console.WriteLine(" --------------------------------------------------");
                    Console.WriteLine("  ==> Loi! Nhap vao gia tri so trong khoang (0,10) ");
                    Console.WriteLine(" --------------------------------------------------");
                }

                Console.Write("\n____________________________________________END____________________________________________\n\n");
            }
        }
        static int[,] InitArray(int n)
        {
            Random random = new Random();
            if (n > 0 && n < 10)
            {
                int[,] array = new int[n, n];
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        array[i, j] = random.Next(1, 100);
                    }
                }
                return array;
            }
            return null;
        }
        static void PrintArray(int[,] array, int n)
        {
            Random random = new Random();
            if (n > 1 && n < 10)
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        Console.Write("\t {0:00}", array[i, j]);
                    }
                    Console.WriteLine();
                }
            }
        }
        static void GetSameValue(int[,] array, int n)
        {
            if (n < 0)
                return;
            int key;
            int[] tarray = new int[n * n];
            int k = 0;
            //copy array
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    tarray[k] = array[i, j];
                    k++;
                }
            }
            //check count
            for (k = 0; k < n * n; k++)
            {
                key = tarray[k];
               
                int count = 0;
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        if (key == array[i, j])
                        {
                            count = count + 1;
                            if (count > 1)
                            {
                                array[i, j] = -1;
                            }
                            
                        }
                    }
                }
                if (count > 1)
                {
                    tarray[k] = count;
                }
                else
                {
                    tarray[k] = 0;
                }
            }
            // print
            k = 0;
            int totalCount = 0;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (tarray[k] > 1)
                    {
                        Console.WriteLine("\t [{0}] \t ==> co {1} gia tri giong nhau", array[i, j], tarray[k]);
                        totalCount++;
                    }
                    k++;
                }
                
            }

            if(totalCount < 1)
            {
                Console.WriteLine("  ==> Khong co gia tri giong nhau ");
            }
            
        }
    }
}
