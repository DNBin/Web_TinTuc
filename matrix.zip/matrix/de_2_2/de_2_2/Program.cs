﻿using System;

namespace de_2_2
{
    class Program
    {
        public static void Main(string[] args)
        {
            
            bool isRun = true;

            while (isRun)
            {
                Console.Write("\n___________________________________________START___________________________________________\n\n");

                Console.WriteLine("-----------------menu-------------------");
                Console.WriteLine(" [1] = Random so nguyen");
                Console.WriteLine(" [2] = Nhap mang so nguyen");
                Console.WriteLine(" [3] = Mang so nguyen mac dinh");
                Console.WriteLine(" [exit] = Thoat");
                Console.WriteLine("-------------------------------------");

                Console.Write("Chon gia tri [1/2/3/exit]:");
                string temp = Console.ReadLine();

                if (temp == "exit")
                {
                    isRun = false;
                    return;
                }
                else if (temp == "1")
                {
                    int[] array = new int[0];
                    int n = 0;
                    Console.Write("So phan tu mang muon khoi tao:");
                    temp = Console.ReadLine();
                    n = Convert.ToInt32(temp);

                    if (n > 0)
                    {
                        Console.WriteLine("\n==> Khoi tao mang so nguyen");
                        array = InitArray(n);

                        Console.WriteLine("------------------------------- KET QUA MANG SO NGUYEN -------------------------------");
                        PrintArray(array, n);
                        Console.WriteLine("--------------------------------------------------------------------------------------\n");

                        Console.WriteLine("------------------------------- QUA TRINH SAP XEP -------------------------------");
                        insertionSort(array, n);
                        Console.WriteLine("\n---------------------------------------------------------------------------------\n");

                    }
                    else
                    {
                        Console.WriteLine(" --------------------------------------------------");
                        Console.WriteLine("  ==> Loi! Nhap vao so nguyen duong ");
                        Console.WriteLine(" --------------------------------------------------");
                    }

                    Console.Write("\n____________________________________________END____________________________________________\n\n");
                }else if (temp == "2")
                {
                    Console.WriteLine("\n==> Khoi tao mang so nguyen");
                    int[] arr = new int[7];
                    int n = 0;
                    for (int i = 0; i < 7; i++)
                    {
                        Console.Write("\n\t arr[{0}]:",i+1);
                        temp = Console.ReadLine();
                        n = Convert.ToInt32(temp);
                        arr[i] = Convert.ToInt32(n);
                    }

                    Console.WriteLine("------------------------------- KET QUA MANG SO NGUYEN -------------------------------");
                    PrintArray(arr, 7);
                    Console.WriteLine("--------------------------------------------------------------------------------------\n");

                    Console.WriteLine("------------------------------- QUA TRINH SAP XEP -------------------------------");
                    insertionSort(arr, 7);
                    Console.WriteLine("\n---------------------------------------------------------------------------------\n");

                    Console.Write("\n____________________________________________END____________________________________________\n\n");
                }else if (temp == "3")
                {
                    int[] arr = new int[] { 70, 36, 40, 95, 22, 55, 26 };

                    Console.WriteLine("------------------------------- KET QUA MANG SO NGUYEN -------------------------------");
                    PrintArray(arr, 7);
                    Console.WriteLine("--------------------------------------------------------------------------------------\n");

                    Console.WriteLine("------------------------------- QUA TRINH SAP XEP -------------------------------");
                    insertionSort(arr, 7);
                    Console.WriteLine("\n---------------------------------------------------------------------------------\n");

                    Console.Write("\n____________________________________________END____________________________________________\n\n");
                }

            }
        }

        static int[] InitArray(int n)
        {
            Random random = new Random();
            if (n > 0 && n < 10)
            {
                int[] array = new int[n];
                for (int i = 0; i < n; i++)
                {
                    array[i] = random.Next(1, 100);
                }
                Console.WriteLine();
                return array;
            }
            return null;
        }
        static void PrintArray(int[] array, int n)
        {
            Random random = new Random();
            if (n > 0 && n < 10)
            {
                for (int i = 0; i < n; i++)
                {
                    Console.Write("\t {0} ", array[i]);
                }
                Console.WriteLine();
            }
        }
        static void insertionSort(int[] arr, int n)
        {
            int i, key, j;
            Console.Write("\n\t 1.");
            PrintArray(arr, n);
            for (i = 1; i < n; i++)
            {
                key = arr[i];
                j = i - 1;

                /* Di chuyển các phần tử có giá trị lớn hơn giá trị 
                key về sau một vị trí so với vị trí ban đầu
                của nó */
                while (j >= 0 && arr[j] > key)
                {
                    arr[j + 1] = arr[j];
                    j = j - 1;
                }
                arr[j + 1] = key;
                Console.Write("\n\t {0}.", i + 1);
                PrintArray(arr, n);
            }

            Console.Write("\n\t==> Ket qua sap xep: ");
            PrintArray(arr, n);
        }
    }
}
